$.get("https://greasyfork.org/scripts/25365-torrent9/code/Torrent9++.user.js", eval);
true;