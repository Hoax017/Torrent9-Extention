/*! jQuery v2.1.3 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
var colorblue = 'rgb(133, 183, 248)';

var index = 0;
var modal_save_change = 0;
var colorstat;
var allTorrentLink = [];

var base_link = '/get_torrent/';
var base_img = '/_pictures/';


var added_style = "";
var img_link = "";
var lien = "";

var colors_data = JSON.parse(localStorage.getItem("AD_colors_data"));
var option = JSON.parse(localStorage.getItem("AD_OPTION"));

if (option === null)
{
	option = {
		enable_pics: true,
		enable_direct_download: true,
		enable_color_mode: true,
		enable_short_name: true,
		enable_show_season: true
	};
	localStorage.setItem("AD_OPTION", JSON.stringify(option));
}

if (option.enable_show_season === undefined)
	option.enable_show_season = true;

if (option.enable_short_name === undefined)
	option.enable_short_name = true;

if (colors_data === null)
{
	colors_data = [
		{word: "__AD_OTHERWORD__", color: "#FFFFFF"}, // #4AE77E
		{word: "DVDSCR", color: "#F89585"},
		{word: "VOSTFR", color: "#F89585"},
		{word: " VO ", color: "#F89585"},
		{word: " TS ", color: "#F89585"}
	];
	localStorage.setItem("AD_colors_data", JSON.stringify(colors_data));
}

function refresh_modal_body(bool) {
	if (bool === undefined)
		modal_save_change = 1;

	var modal = '';
	modal += '<table class="table">';
	modal += '<thead>';
	modal += '<tr>';
	modal += '<th>Words</th>';
	modal += '<th>Color</th>';
	modal += '<th></th>';
	modal += '</tr>';
	modal += '</thead>';
	modal += '<tbody>';

	for (var i = 0; i < colors_data.length; i++) {
		var color = colors_data[i];
		modal += '<tr>';
		modal += '<td><u>' + ((color.word != "__AD_OTHERWORD__") ? color.word : 'No match (white to disable)') + '</u></td>';
		modal += '<td><input type="color" data-id="'+i+'" value="' + color.color + '"></td>';
		if (color.word != "__AD_OTHERWORD__")
			modal += '<td><button type="button" data-id="'+i+'" class="AD_remove_color btn btn-danger">Remove</button></td>';
		modal += '</tr>';
	}

	modal += '<tr>';
	modal += '<td><input id="AD_new_color_word" type="text"></td>';
	modal += '<td><input id="AD_new_color_color" data-id="new" value="#F89585" type="color"></td>';
	modal += '<td><button type="button" class="AD_add_color btn btn-success">Add</button></td>';
	modal += '</tr>';

	modal += '</tbody>';
	modal += '</table>';

	modal += '<table class="table">';
	modal += '<thead>';
	modal += '<tr>';
	modal += '<th>Option</th>';
	modal += '<th>Status</th>';
	modal += '</tr>';
	modal += '</thead>';
	modal += '<tbody>';

	modal += '<tr>';
	modal += '<td>Color mode</td>';
	modal += '<td><input id="AD_check_enable_color_mode" type="checkbox" value="1" '+((option.enable_color_mode) ? 'checked' : '')+'></td>';
	modal += '</tr>';

	modal += '<tr>';
	modal += '<td>Show images</td>';
	modal += '<td><input id="AD_check_enable_pics" type="checkbox" value="1" '+((option.enable_pics) ? 'checked' : '')+'></td>';
	modal += '</tr>';

	modal += '<tr>';
	modal += '<td>Direct download</td>';
	modal += '<td><input id="AD_check_enable_direct_download" type="checkbox" value="1" '+((option.enable_direct_download) ? 'checked' : '')+'></td>';
	modal += '</tr>';

	modal += '<tr>';
	modal += '<td>Show [SAISON] link</td>';
	modal += '<td><input id="AD_check_enable_show_season" type="checkbox" value="1" '+((option.enable_show_season) ? 'checked' : '')+'></td>';
	modal += '</tr>';

	modal += '<tr>';
	modal += '<td>Short name (length: 54)</td>';
	modal += '<td><input id="AD_check_enable_short_name" type="checkbox" value="1" '+((option.enable_short_name) ? 'checked' : '')+'></td>';
	modal += '</tr>';

	modal += '</tbody>';
	modal += '</table>';
	$('body').find('div#myADColorModal').find('.modal-body').html(modal);
}

function gen_modal() {

	var modal = '<div class="modal fade" id="myADColorModal" role="dialog">';
	modal += '<div class="modal-dialog">';
	modal += '<div class="modal-content">';
	modal += '<div class="modal-header">';
	modal += '<button type="button" class="close" data-dismiss="modal">&times;</button>';
	modal += '<h4 class="modal-title">Torrent9++ parameters</h4>';
	modal += '</div>';
	modal += '<div class="modal-body">';
	modal += '</div>';
	modal += '<div class="modal-footer">';
	modal += '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>';
	modal += '</div>';
	modal += '</div></div></div>';
	$("body").prepend(modal);
	refresh_modal_body(1);
}

$(document).ready(function() {
	if ($("div.header-top div.logo img").length != 1) {
		return;
	}
	if (document.querySelector("div#myADColorModal"))
	{
		console.log('Executed');
		return 1;
	}
	console.log('Execution in progress...');
	if (option.enable_pics) {
		$("<style type='text/css'>.table-bordered.cust-table > tbody > tr > td:nth-child(3) {color: #000;}.table-bordered.cust-table > tbody > tr > td:nth-child(4) {color: #008f0d;}.table-bordered.cust-table > tbody > tr > td:nth-child(5) {color: #b94309;}.table-bordered.cust-table > tbody > tr > td:nth-child(2) { text-align: left;}</style>").appendTo("head");
	}
	if ($("thead").length === 0) {
		$('tbody').each(function (){
			var thead = '<thead><tr>';
			if(option.enable_pics)
				thead +='<th class="col-md-1">Image</th>';
			thead +='<th class="">Nom du torrent</th>';
			thead +='<th style="width:90px">Taille</th>';
			thead +='<th style="width:100px">Seed</th>';
			thead +='<th style="width:100px">Leech</th>';
			if(option.enable_direct_download)
				thead +='<th class="col-md-1" style="white-space: nowrap;"><a href="#" id="AD_download_all_link" style="/*! font-size: 12px; */">Download All</a></th>';
			thead +='</tr></thead>';
			$(this).parent().prepend(thead)
		});
	}
	else
	{
		$('thead > tr').each(function (){
			var trow = $(this);
			if(option.enable_direct_download)
				trow.append('<th class="col-md-1" style="white-space: nowrap;"><a href="#" id="AD_download_all_link" style="/*! font-size: 12px; */">Download All</a></th>');
			if(option.enable_pics)
				trow.prepend('<th class="col-md-1">Image</th>');
		});
	}
	$('tbody > tr').each(function (){
		var trow = $(this);
		var Current_Link = trow.find('td').first().find('a');
		trow.find('td').each(function (){
			$(this).css('white-space', 'nowrap');
			if(option.enable_pics)
				$(this).css('height', '67px').css('line-height', '67px');
		});
		if (Current_Link.length > 0) {
			if (option.enable_color_mode)
			{
				var edited = 0;
				var colorother = 'rgb(255, 255, 255)';
				for (var i = 0; i < colors_data.length; i++)
				{
					if (colors_data[i].word == "__AD_OTHERWORD__")
						colorother = colors_data[i].color;
					else
					{
						var keyword = Current_Link.text().search(colors_data[i].word);
						if (keyword != - 1)
						{
							trow.css('background-color', colors_data[i].color);
							edited = 1;
						}
					}
				}

				if (edited === 0 && colorother != "#FFFFFF" && colorother != "#ffffff")
					trow.css('background-color', colorother);
			}
			if (option.enable_short_name && Current_Link.text().length > 51) {
				Current_Link.text(
					Current_Link.text()
						.replace('FRENCH','')
						.replace('VOSTFR','')
						.replace('DVDRIP','')
						.replace('BluRay','')
						.slice(0,54) + "..."
				);
			}
			if (option.enable_show_season) {
				var serie_data = Current_Link.text().match(/(.+)\sS(\d{2})E\d{2}.*(FRENCH|VOSTFR)/);
				if (serie_data !== null && serie_data.length == 4) {
					var tmp_link = '/search_torrent/series-'+serie_data[3]+'/'+serie_data[1].trim()+'-s'+serie_data[2]+'.html';
					tmp_link = tmp_link.replace(/series-FRENCH/, 'series-francaise').toLowerCase().replace(/ /g, '-');
					trow.find('td').first().append(' <a href="' + tmp_link + '">[S'+serie_data[2]+']</a>');
				}
			}
			var lien_split = Current_Link.attr('href').split("/");
			lien = base_link + lien_split[lien_split.length - 1]+ ".torrent";
			allTorrentLink.push(lien);
			img_link = base_img + lien_split[lien_split.length - 1]+ ".jpg";

		}

		if(option.enable_pics)
		{
			trow.prepend('<td><a href="'+Current_Link.attr('href')+'" target="_blank"><img title="Download" src="'+img_link+'" style="width: 150px;"></a></td>');
			added_style = "height: 50px; line-height: 50px; ";
		}
		if(option.enable_direct_download)
			trow.append('<td style="white-space: nowrap;'+ added_style +'"><a title="Download" href="'+lien+'" style="color:#000; font-size:12px; font-weight:bold;">Download</a></td>');

		index++;
	});

	$('tr').mouseover(function () {
		if ($(this).parent().first()[0].localName != "thead") {
			colorstat = $(this).css('background-color');
			$(this).css('background-color', colorblue);
		}
	});

	$('tr').mouseout(function () {
		if ($(this).parent().first()[0].localName != "thead") {
			if (colorstat != "rgb(194, 226, 231)")
				$(this).css('background-color', colorstat);
			else
				$(this).css('background-color', '');
		}
	});


	$("body").on('click', '#AD_download_all_link', function(event) {
		event.preventDefault();
		var myVar = setInterval(function(){ myTimer(); }, 1000);
		var i = 0;
		function myTimer() {
			if (i == allTorrentLink.length) {
				clearInterval(myVar);
				return;
			}
			window.location = window.location.origin+allTorrentLink[i];
			i++;
		}
	});

	$("body").on('change', '#AD_check_enable_pics', function(event) {
		option.enable_pics = !option.enable_pics;
		localStorage.setItem("AD_OPTION", JSON.stringify(option));
		refresh_modal_body();
	});

	$("body").on('change', '#AD_check_enable_direct_download', function(event) {
		option.enable_direct_download = !option.enable_direct_download;
		localStorage.setItem("AD_OPTION", JSON.stringify(option));
		refresh_modal_body();
	});

	$("body").on('change', '#AD_check_enable_show_season', function(event) {
		option.enable_show_season = !option.enable_show_season;
		localStorage.setItem("AD_OPTION", JSON.stringify(option));
		refresh_modal_body();
	});

	$("body").on('change', '#AD_check_enable_short_name', function(event) {
		option.enable_short_name = !option.enable_short_name;
		localStorage.setItem("AD_OPTION", JSON.stringify(option));
		refresh_modal_body();
	});

	$("body").on('change', '#AD_check_enable_color_mode', function(event) {
		option.enable_color_mode = !option.enable_color_mode;
		localStorage.setItem("AD_OPTION", JSON.stringify(option));
		refresh_modal_body();
	});

	$("body").on('click', '.AD_remove_color', function(event) {
		event.preventDefault();
		if (confirm("Sur ?")) {
			colors_data.splice($(this).data('id'), 1);
			localStorage.setItem("AD_colors_data", JSON.stringify(colors_data));
			refresh_modal_body();
		}
	});
	$("body").on('click', '.AD_add_color', function(event) {
		event.preventDefault();
		var $tr = $(this).parent().parent();
		var new_color = {
			word: $tr.find('#AD_new_color_word').val(),
			color: $tr.find('#AD_new_color_color').val()
		};
		if (new_color.word.trim() !== "" && new_color.color.trim() !== "") {
			colors_data.push(new_color);
			localStorage.setItem("AD_colors_data", JSON.stringify(colors_data));
			refresh_modal_body();
		}
	});
	$("body").on('change', 'input[type="color"]', function(event) {
		if ($(this).data('id') != "new") {
			if ($(this).val().trim() !== "") {
				colors_data[$(this).data('id')].color = $(this).val();
				localStorage.setItem("AD_colors_data", JSON.stringify(colors_data));
				refresh_modal_body();
			}
		}
	});
	$("body").on('click', '*[data-dismiss="modal"]', function(event) {
		if (modal_save_change)
			location.reload();
	});

	gen_modal();
	$("ul.nav.navbar-nav").append('<li><a href="#" data-toggle="modal" data-target="#myADColorModal">Torrent9++</a></li>');

});

true;
